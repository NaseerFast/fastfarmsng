"use strict";
exports.id = 852;
exports.ids = [852];
exports.modules = {

/***/ 4852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Layout)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Layout/Footer.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





var LogoVPN = function LogoVPN(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M261.3 15.5c-11 3.1-20.1 9.7-24.9 18.4-2.6 4.6-2.7 4.6-13.4 7.8C167.8 58.1 119.9 98 92.7 150c-16.4 31.2-24.9 65.6-26.4 106.1l-.6 16.7-7.1 3.3c-10.9 5.3-23.6 14-29.3 20.2-7.5 8.3-9.6 14.5-9.1 27.2.3 8.8.8 11 4 18.3 9.2 21 24.4 42 46.2 63.7 28.1 27.8 54.5 46.9 86.6 62.4 25.7 12.4 48.7 19.4 73.7 22.6 17.1 2.2 83.8 1.6 99.8-.8 34.3-5.3 62.6-15.5 86.8-31.3 14.5-9.4 30.8-25.9 36.5-37.1 6.6-12.8 8.4-20.9 8.6-39.8l.3-16 4.5-9.5c9.2-19.2 15.6-39.6 19.9-63 2.7-14.6 3.8-51.4 2-67.1-8.2-71-45.6-133.9-103.6-174.1-23.7-16.4-52.8-29.5-78.5-35.3-10.6-2.4-38.6-3-45.7-1zm54.2 25c24.3 4.3 38.4 10.6 49.7 22 9.8 10 13.8 22.3 13.8 42.6 0 11.2-2 31.8-3.6 37.3-.4 1.3-.2 1.7.7 1.4 3.7-1.3 7.2 3.5 8.3 11.5l.7 4.8 3-2.6c5.7-4.7 11.7-4.3 14.1 1.1 1 2.1.9 3.5-.5 7.4-2.5 6.9-2.2 9.4 1.5 12.7 10.6 9.5 12.8 14.8 10.5 25.4-.7 3.5-.7 3.6 6.2 8.2 7.2 5 11.5 10.1 13.1 15.8 1.9 6.6 2 6.6-19.3 7.5l-19.2.9-.3 2.8c-.2 1.5 1 6.7 2.6 11.5 5.9 17 6.3 24.4 2.2 34.1l-2.1 4.8 12.4 18.4c15 22.3 19.7 30.2 23.6 39.6 13 31.6 4.4 58.8-26.3 82.8-15.2 11.8-32 20.6-52.8 27.6-52.2 17.4-110.6 13.6-160.3-10.5C118.9 411.3 72 336.2 72 253c0-72.9 36.1-140.3 96.5-180.3 12.5-8.3 34.7-19 49-23.6 12.6-4.1 33.5-8.6 47-10.1 11.4-1.3 40.4-.4 51 1.5z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M356.9 127c-1.5 2.2-3.2 6-3.9 8.5-1.4 4.8-2 5.4-4 3-1.6-1.9-4-1.9-6.8.1-2 1.4-2.4 1.3-5.7-1.1-11-8.5-23.6-.3-22.2 14.4.6 6.8 2.1 10.1 8.1 17.5 2.5 3 4.2 5.7 3.9 6-.4.3-2.2.6-4.2.6-5.9 0-23.2 4.6-32.7 8.7-26.3 11.4-47.5 32.3-63.4 62.5-4.9 9.3-28.1 61.9-46.5 105.3-5.4 12.6-11.3 26.6-13.1 31-3 6.9-3.2 8.1-2 9.4 1.8 1.7 4.1.3 5.2-3.1 1.2-3.8 32.2-76.2 47.9-111.8 16.1-36.6 24.7-50.3 41.9-66.7 14.4-13.8 29.2-22.2 48.6-27.5 7.3-2 10.8-2.3 24.5-2.3 11.9.1 16.9.4 19.3 1.5 3.3 1.5 3.3 1.5-4.5 1.6-20.2.4-38.1 14-38.3 29.2 0 3.7 1.3 4.5 9.1 5.6 6.3.9 13.2 5.5 16.2 10.8 2.5 4.3 4.2 9.8 3.2 9.8-.3 0-4.1-2-8.4-4.5-8.5-4.9-13-5.6-18.2-3-4.6 2.4-6.9 7-6.9 13.8 0 11.3 3.4 15.3 22.9 26.1 13.1 7.3 13.4 7.6 16.3 13.3 1.6 3.2 4 6.9 5.3 8.3 2.7 2.9 12.4 21.9 18.8 37 9.8 23.3 15.5 44.1 16.5 60.9.7 10.2.8 10.6 3.1 10.9l2.4.4-.6-12.9c-.9-21.3-8.2-45.1-24.3-78.8-2.1-4.4-4-8.2-4.1-8.5-.2-.3 3.2-.5 7.5-.5 9.3 0 18-3 24.1-8.2 4.2-3.6 5.1-6.2 2.8-8.2-1-.8-1.9-.4-3.5 1.8-5.7 7.8-24.7 11.8-33.1 7-4.7-2.6-8.4-7.5-11.3-15-1.6-4.4-2.2-9.2-2.9-24.8-.8-15.9-1.3-20.2-3-24-3.9-8.9-12.9-15.7-23.2-17.6-3.3-.6-3.7-1-3.1-2.9 1.4-4.5 3.5-7.5 8-11.5 11.4-10.1 32.6-12 42.8-4l2.6 2 .1-2.8c0-1.5.4-3.7.8-4.8.7-1.7 1.1-1.5 3.7 2.1 1.6 2.2 3.8 5.7 4.9 7.7 1.8 3.4 1.8 3.8.3 5.3-1.7 1.7-2.5 1.2-7.2-5.1-1.4-1.8-1.5-1.1-1.6 8.6 0 24.1 7.2 48 21.5 70.9 3 4.8 3.5 5.2 4.2 3.5.4-1.1.8-6.3.7-11.5-.1-8.1-.5-10.7-3.2-17.8-1.9-4.8-3.2-10.2-3.2-12.8 0-4.1-.2-4.4-2.6-4.4-1.5 0-4.4 1-6.5 2.2-3.1 1.7-4.2 1.9-5.1 1-2-2 .2-4.3 8.3-8.9 13.7-7.6 13.4-7.4 13.3-11.8-.1-2.2-.5-5.1-.9-6.5-.5-1.8 0-3.3 1.6-5.4 2-2.5 2.7-2.8 6.5-2.2 4.3.5 4.3.5 5-2.9 1.2-6.6-.3-10.3-6.7-16.4-6.9-6.6-8-10-5.9-18.7 2-8.4.4-8.9-6.9-1.9-3.5 3.4-6.6 5.5-7.4 5.2-.9-.3-1.7-3-2.1-7.9-.8-8.4-1.5-11.8-2.5-11.8-2 0-4.2 6.9-5.6 18.1-.9 6.8-1.8 13.9-2.1 15.7l-.5 3.2-3.7-2.9c-4.7-3.8-12.5-6.8-19.4-7.6-9-1.1-11.4-2.3-17.6-9-9.4-9.9-11.5-19.6-5.8-26.1 3.3-4 8.2-2.8 13.5 3.3 4.4 5 6.4 5.1 8.2.7 1.2-3.4 2.6-2.2 3.1 2.6.2 2.8.8 3.6 2.6 3.8 1.9.3 2.6-.5 4.6-5 1.3-2.9 3.2-7.9 4.2-11.1 1-3.1 2.3-5.7 2.9-5.7 2.1 0 3.8 8.4 4 20.4.2 8.7.6 12 1.6 12.6 2.2 1.4 3.7-.8 4.9-6.8.6-3.1 1.3-6.7 1.6-7.9.3-1.6 0-2.1-.9-1.7-1.1.4-1.5-1.1-2-6-.7-7.6-2.8-13-5.9-15.6-3.4-2.9-5.1-2.4-7.9 2zm-28.4 114.3l9 5.2.8 7c.4 3.9.6 9.8.5 13.2l-.3 6.2-12.2-7c-14.9-8.5-16.8-10.8-16.8-19.7 0-5.5.3-6.6 2.4-8.3 3.6-2.9 6.8-2.3 16.6 3.4z"
    }), /*#__PURE__*/jsx_runtime_.jsx("path", {
      d: "M350.6 200.1c-10.6 3-12.1 16.7-2.6 23.2 7.4 5.1 19-1.7 19-11.1 0-8.1-8.5-14.4-16.4-12.1zm8.2 6.6c1.2 1 2.4 3 2.8 4.5.5 2.2 0 3.3-2.4 5.8-3.7 3.6-6.5 3.8-9.7.5-6.8-6.7 2.1-16.9 9.3-10.8zM401.6 213.5c.7 1.9 1.4 4.6 1.4 6 0 2.3.4 2.5 4.3 2.6 2.3 0 7.4.8 11.2 1.9 3.9 1 7.2 1.6 7.4 1.4.3-.2-1.5-2.3-4-4.7-4.6-4.4-16.2-10.7-19.7-10.7-2 0-2 .2-.6 3.5z"
    })]
  }));
};

LogoVPN.defaultProps = {
  version: "1",
  xmlns: "http://www.w3.org/2000/svg",
  width: "682.667",
  height: "682.667",
  viewBox: "0 0 512.000000 512.000000"
};

var Facebook = function Facebook(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      fill: "#7b904b",
      d: "M15.12 5.32H17V2.14A26.11 26.11 0 0 0 14.26 2c-2.72 0-4.58 1.66-4.58 4.7v2.62H6.61v3.56h3.07V22h3.68v-9.12h3.06l.46-3.56h-3.52V7.05c0-1.05.28-1.73 1.76-1.73z"
    })
  }));
};

Facebook.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24"
};

var Twitter = function Twitter(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      fill: "#7b904b",
      d: "M22.162 5.656a8.384 8.384 0 0 1-2.402.658A4.196 4.196 0 0 0 21.6 4c-.82.488-1.719.83-2.656 1.015a4.182 4.182 0 0 0-7.126 3.814 11.874 11.874 0 0 1-8.62-4.37 4.168 4.168 0 0 0-.566 2.103c0 1.45.738 2.731 1.86 3.481a4.168 4.168 0 0 1-1.894-.523v.052a4.185 4.185 0 0 0 3.355 4.101 4.21 4.21 0 0 1-1.89.072A4.185 4.185 0 0 0 7.97 16.65a8.394 8.394 0 0 1-6.191 1.732 11.83 11.83 0 0 0 6.41 1.88c7.693 0 11.9-6.373 11.9-11.9 0-.18-.005-.362-.013-.54a8.496 8.496 0 0 0 2.087-2.165z"
    })
  }));
};

Twitter.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24"
};

var Instagram = function Instagram(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({}, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      fill: "#7b904b",
      d: "M12 2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.217 2.428.465.66.254 1.216.598 1.772 1.153a4.908 4.908 0 0 1 1.153 1.772c.247.637.415 1.363.465 2.428.047 1.066.06 1.405.06 4.122 0 2.717-.01 3.056-.06 4.122-.05 1.065-.218 1.79-.465 2.428a4.883 4.883 0 0 1-1.153 1.772 4.915 4.915 0 0 1-1.772 1.153c-.637.247-1.363.415-2.428.465-1.066.047-1.405.06-4.122.06-2.717 0-3.056-.01-4.122-.06-1.065-.05-1.79-.218-2.428-.465a4.89 4.89 0 0 1-1.772-1.153 4.904 4.904 0 0 1-1.153-1.772c-.248-.637-.415-1.363-.465-2.428C2.013 15.056 2 14.717 2 12c0-2.717.01-3.056.06-4.122.05-1.066.217-1.79.465-2.428a4.88 4.88 0 0 1 1.153-1.772A4.897 4.897 0 0 1 5.45 2.525c.638-.248 1.362-.415 2.428-.465C8.944 2.013 9.283 2 12 2zm0 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm6.5-.25a1.25 1.25 0 0 0-2.5 0 1.25 1.25 0 0 0 2.5 0zM12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"
    })
  }));
};

Instagram.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg",
  width: "1em",
  height: "1em",
  viewBox: "0 0 24 24"
};

const Footer = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-white-300 pt-44 pb-24",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "max-w-screen-xl w-full mx-auto px-6 sm:px-8 lg:px-16 grid grid-rows-6 sm:grid-rows-1 grid-flow-row sm:grid-flow-col grid-cols-3 sm:grid-cols-12 gap-4",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "row-span-2 sm:col-span-4 col-start-1 col-end-4 sm:col-end-5 flex flex-col items-start ",
        children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
          src: "/assets/logo.png",
          alt: "logo",
          width: "60px",
          height: ""
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "mb-4",
          children: [/*#__PURE__*/jsx_runtime_.jsx("strong", {
            className: "font-medium",
            children: "FastFarms"
          }), " is a startup that focuses on providing a better plan for chicken and meat supply chain."]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex w-full mt-2 mb-8 -mx-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "mx-2 bg-white-500 rounded-full items-center justify-center flex p-2 shadow-md",
            children: /*#__PURE__*/jsx_runtime_.jsx(Facebook, {
              className: "h-6 w-6"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "mx-2 bg-white-500 rounded-full items-center justify-center flex p-2 shadow-md",
            children: /*#__PURE__*/jsx_runtime_.jsx(Twitter, {
              className: "h-6 w-6"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "mx-2 bg-white-500 rounded-full items-center justify-center flex p-2 shadow-md",
            children: /*#__PURE__*/jsx_runtime_.jsx(Instagram, {
              className: "h-6 w-6"
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "text-gray-400",
          children: ["\xA9", new Date().getFullYear(), " - FastFarms"]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: " row-span-2 sm:col-span-2 sm:col-start-7 sm:col-end-9 flex flex-col",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-black-600 mb-4 font-medium text-lg",
          children: "Product"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "text-black-500 ",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Download", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Pricing", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Locations", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Server", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Countries", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Blog", " "]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "row-span-2 sm:col-span-2 sm:col-start-9 sm:col-end-11 flex flex-col",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-black-600 mb-4 font-medium text-lg",
          children: "Engage"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "text-black-500",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["FastFarms ?", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["FAQ", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Tutorials", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["About Us", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Privacy Policy", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Terms of Service", " "]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "row-span-2 sm:col-span-2 sm:col-start-11 sm:col-end-13 flex flex-col",
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-black-600 mb-4 font-medium text-lg",
          children: "Earn Money"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "text-black-500",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Affiliate", " "]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
            className: "my-2 hover:text-green-500 cursor-pointer transition-all",
            children: ["Become Partner", " "]
          })]
        })]
      })]
    })
  });
};

/* harmony default export */ const Layout_Footer = (Footer);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
// EXTERNAL MODULE: ./components/misc/ButtonOutline..js
var ButtonOutline_ = __webpack_require__(8425);
;// CONCATENATED MODULE: ./components/Layout/Header.js

 // Import react scroll



 // import { LogoVPN } from "../../public/assets/Logo.png";





const Header = () => {
  const {
    0: activeLink,
    1: setActiveLink
  } = (0,external_react_.useState)(null);
  const {
    0: scrollActive,
    1: setScrollActive
  } = (0,external_react_.useState)(false);
  const cart = (0,external_react_redux_.useSelector)(state => state.cart);
  (0,external_react_.useEffect)(() => {
    window.addEventListener("scroll", () => {
      setScrollActive(window.scrollY > 20);
    });
  }, []);

  const getItemsCount = () => {
    return cart.reduce((accumulator, item) => accumulator + item.quantity, 0);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("header", {
      className: "fixed top-0 w-full  z-30 bg-white-500 transition-all " + (scrollActive ? " shadow-md pt-0" : " pt-4"),
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
        className: "max-w-screen-xl px-6 sm:px-8 lg:px-16 mx-auto grid grid-flow-col py-3 sm:py-4",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-start-1 col-end-2 flex items-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/assets/logo.png",
            alt: "logo",
            width: "60px",
            height: ""
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "hidden lg:flex col-start-4 col-end-8 text-black-500  items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx(external_react_scroll_.Link, {
            activeClass: "active",
            to: "about",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("about");
            },
            className: "px-4 py-2 mx-2 cursor-pointer animation-hover inline-block relative" + (activeLink === "about" ? " text-green-500 animation-active " : " text-black-500 hover:text-green-500 a"),
            children: "About"
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_scroll_.Link, {
            activeClass: "active",
            to: "feature",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("feature");
            },
            className: "px-4 py-2 mx-2 cursor-pointer animation-hover inline-block relative" + (activeLink === "feature" ? " text-green-500 animation-active " : " text-black-500 hover:text-green-500 "),
            children: "Feature"
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_scroll_.Link, {
            activeClass: "active",
            to: "pricing",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("pricing");
            },
            className: "px-4 py-2 mx-2 cursor-pointer animation-hover inline-block relative" + (activeLink === "pricing" ? " text-geen-500 animation-active " : " text-black-500 hover:text-green-500 "),
            children: "Products"
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_scroll_.Link, {
            activeClass: "active",
            to: "testimoni",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("testimoni");
            },
            className: "px-4 py-2 mx-2 cursor-pointer animation-hover inline-block relative" + (activeLink === "testimoni" ? " text-green-500 animation-active " : " text-black-500 hover:text-green-500 "),
            children: "Testimonial"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "col-start-10 col-end-12 font-medium flex justify-end items-center",
          children: [/*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "text-black-600 mx-2 sm:mx-4 capitalize tracking-wide hover:text-green-500 transition-all",
              children: "\xA0 Sign In"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx((link_default()), {
            href: "/cart",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: ["Cart (", getItemsCount(), ")"]
            })
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("nav", {
      className: "fixed lg:hidden bottom-0 left-0 right-0 z-20 px-4 sm:px-8 shadow-t ",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "bg-white-500 sm:px-3",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
          className: "flex w-full justify-between items-center text-black-500",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_scroll_.Link, {
            activeClass: "active",
            to: "about",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("about");
            },
            className: "mx-1 sm:mx-2 px-3 sm:px-4 py-2 flex flex-col items-center text-xs border-t-2 transition-all " + (activeLink === "about" ? "  border-green-500 text-green-500" : " border-transparent"),
            children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
              className: "w-6 h-6",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              xmlns: "http://www.w3.org/2000/svg",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              })
            }), "About"]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_scroll_.Link, {
            activeClass: "active",
            to: "feature",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("feature");
            },
            className: "mx-1 sm:mx-2 px-3 sm:px-4 py-2 flex flex-col items-center text-xs border-t-2 transition-all " + (activeLink === "feature" ? "  border-green-500 text-green-500" : " border-transparent "),
            children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
              className: "w-6 h-6",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              xmlns: "http://www.w3.org/2000/svg",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
              })
            }), "Feature"]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_scroll_.Link, {
            activeClass: "active",
            to: "pricing",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("pricing");
            },
            className: "mx-1 sm:mx-2 px-3 sm:px-4 py-2 flex flex-col items-center text-xs border-t-2 transition-all " + (activeLink === "pricing" ? "  border-green-500 text-green-500" : " border-transparent "),
            children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
              className: "w-6 h-6",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              xmlns: "http://www.w3.org/2000/svg",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              })
            }), "Pricing"]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_scroll_.Link, {
            activeClass: "active",
            to: "testimoni",
            spy: true,
            smooth: true,
            duration: 1000,
            onSetActive: () => {
              setActiveLink("testimoni");
            },
            className: "mx-1 sm:mx-2 px-3 sm:px-4 py-2 flex flex-col items-center text-xs border-t-2 transition-all " + (activeLink === "testimoni" ? "  border-green-500 text-green-500" : " border-transparent "),
            children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
              className: "w-6 h-6",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              xmlns: "http://www.w3.org/2000/svg",
              children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
              })
            }), "Testimonial"]
          })]
        })
      })
    })]
  });
};

/* harmony default export */ const Layout_Header = (Header);
;// CONCATENATED MODULE: ./components/Layout/Layout.js







const Layout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Layout_Header, {}), children, /*#__PURE__*/jsx_runtime_.jsx(Layout_Footer, {})]
  });
};

/* harmony default export */ const Layout_Layout = (Layout);

/***/ }),

/***/ 8425:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const ButtonOutline = ({
  children
}) => {
  return /*#__PURE__*/_jsxs("button", {
    className: "font-medium tracking-wide py-2 px-5 sm:px-8 border border-green-500 text-white-500 bg-green-500 outline-none rounded-l-full rounded-r-full capitalize hover:bg-green-500 hover:text-white-500 transition-all hover:shadow-green ",
    children: [" ", children]
  });
};

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ButtonOutline)));

/***/ })

};
;