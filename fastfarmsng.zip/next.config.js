module.exports = {
    images: {
      domains: ['imgur.com'],
    },
  };